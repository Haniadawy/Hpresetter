package com.hani.hpresetter

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.github.ykc3.android.usbi2c.UsbI2cAdapter
import com.github.ykc3.android.usbi2c.UsbI2cDevice
import com.github.ykc3.android.usbi2c.UsbI2cManager
import com.hani.hpresetter.databinding.ActivityMainBinding
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val executor = Executors.newSingleThreadExecutor()

    private var usbManager: UsbManager? = null
    private var i2cAdapter: UsbI2cAdapter? = null
    private var i2cDevice: UsbI2cDevice? = null

    companion object {
        private const val ACTION_USB_PERMISSION = "com.hani.hpresetter.USB_PERMISSION"
        private const val EEPROM_ADDRESS = 0x50
    }

    // خطوة التنفيذ المطلوبة عند الضغط على أي زر من القائمة
    private sealed class Action(val label: String) {
        data class Burn(val name: String, val data: ByteArray, val startAddr: Int, val delayMs: Long) : Action(name)
        data class Restore(val name: String) : Action(name)
    }

    private var pendingAction: Action? = null

    private val usbPermissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (ACTION_USB_PERMISSION == intent.action) {
                synchronized(this) {
                    val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                    if (granted) {
                        openAdapterAndMaybeRun()
                    } else {
                        showFailureDialog(getString(R.string.err_permission_denied))
                    }
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager

        val filter = IntentFilter(ACTION_USB_PERMISSION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.registerReceiver(this, usbPermissionReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(usbPermissionReceiver, filter)
        }

        binding.btn776.setOnClickListener {
            confirmAndRun(Action.Burn(getString(R.string.menu_776), ChipData.R776, 35, 30))
        }
        binding.btn779.setOnClickListener {
            confirmAndRun(Action.Burn(getString(R.string.menu_779), ChipData.R779, 35, 30))
        }
        binding.btn477577.setOnClickListener {
            confirmAndRun(Action.Restore(getString(R.string.menu_477_577)))
        }
        binding.btn556586.setOnClickListener {
            confirmAndRun(Action.Restore(getString(R.string.menu_556_586)))
        }
        binding.btnA3.setOnClickListener {
            confirmAndRun(Action.Burn(getString(R.string.menu_a3), ChipData.RA3, 0, 5))
        }
        binding.btnRestore.setOnClickListener {
            confirmAndRun(Action.Burn(getString(R.string.menu_restore), ChipData.CHIPLESS577, 0, 30))
        }

        updateStatus(getString(R.string.status_no_device))
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(usbPermissionReceiver) } catch (_: Exception) {}
        closeAdapter()
        executor.shutdownNow()
    }

    private fun confirmAndRun(action: Action) {
        AlertDialog.Builder(this)
            .setTitle(R.string.confirm_title)
            .setMessage(getString(R.string.confirm_message, action.label))
            .setPositiveButton(R.string.confirm_yes) { _, _ -> startFlow(action) }
            .setNegativeButton(R.string.confirm_no, null)
            .show()
    }

    private fun startFlow(action: Action) {
        pendingAction = action
        val mgr = usbManager ?: return

        val i2cManager = UsbI2cManager.create(mgr).build()
        val adapters = i2cManager.adapters
        if (adapters.isEmpty()) {
            showFailureDialog(getString(R.string.status_no_device))
            return
        }

        val adapter = adapters[0]
        i2cAdapter = adapter

        if (mgr.hasPermission(adapter.usbDevice)) {
            openAdapterAndMaybeRun()
        } else {
            updateStatus(getString(R.string.status_connecting))
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                PendingIntent.FLAG_MUTABLE else 0
            val permissionIntent = PendingIntent.getBroadcast(
                this, 0, Intent(ACTION_USB_PERMISSION), flags
            )
            mgr.requestPermission(adapter.usbDevice, permissionIntent)
        }
    }

    private fun openAdapterAndMaybeRun() {
        val adapter = i2cAdapter ?: return
        executor.execute {
            try {
                if (adapter.isClockSpeedSupported(UsbI2cAdapter.CLOCK_SPEED_FAST)) {
                    adapter.setClockSpeed(UsbI2cAdapter.CLOCK_SPEED_FAST)
                }
                adapter.open()
                val device = adapter.getDevice(EEPROM_ADDRESS)
                i2cDevice = device

                runOnUiThread { updateStatus(getString(R.string.status_connected)) }

                val action = pendingAction
                pendingAction = null
                if (action != null) {
                    runAction(device, action)
                }
            } catch (e: Exception) {
                runOnUiThread { showFailureDialog(getString(R.string.err_connection_failed)) }
            }
        }
    }

    /** ينفّذ عملية الكتابة الفعلية على thread منفصل، ويعرض إشعار نجاح/فشل بس — بدون أي بايتات. */
    private fun runAction(device: UsbI2cDevice, action: Action) {
        runOnUiThread {
            binding.progressBar.visibility = android.view.View.VISIBLE
            binding.progressBar.progress = 0
            setButtonsEnabled(false)
        }

        val writer = ChipWriter(device) { percent ->
            runOnUiThread { binding.progressBar.progress = percent }
        }

        executor.execute {
            try {
                writer.checkConnection()
                when (action) {
                    is Action.Burn -> writer.burnArray(action.data, action.startAddr, action.delayMs)
                    is Action.Restore -> writer.runR586()
                }
                runOnUiThread { showSuccessDialog() }
            } catch (e: ChipWriter.ConnectionFailedException) {
                runOnUiThread { showFailureDialog(getString(R.string.err_connection_failed)) }
            } catch (e: ChipWriter.VerifyFailedException) {
                runOnUiThread { showFailureDialog(getString(R.string.err_verify_failed)) }
            } catch (e: Exception) {
                runOnUiThread { showFailureDialog(getString(R.string.err_connection_failed)) }
            } finally {
                runOnUiThread {
                    binding.progressBar.visibility = android.view.View.GONE
                    setButtonsEnabled(true)
                }
            }
        }
    }

    private fun setButtonsEnabled(enabled: Boolean) {
        binding.btn776.isEnabled = enabled
        binding.btn779.isEnabled = enabled
        binding.btn477577.isEnabled = enabled
        binding.btn556586.isEnabled = enabled
        binding.btnA3.isEnabled = enabled
        binding.btnRestore.isEnabled = enabled
    }

    private fun updateStatus(text: String) {
        binding.tvStatus.text = text
    }

    /** إشعار نجاح الكتابة — النافذة الوحيدة اللي المستخدم عايزها، بدون أي تفاصيل بايتات. */
    private fun showSuccessDialog() {
        AlertDialog.Builder(this)
            .setTitle(R.string.msg_write_success)
            .setPositiveButton(android.R.string.ok, null)
            .setCancelable(true)
            .show()
    }

    /** إشعار فشل الاتصال/العملية. */
    private fun showFailureDialog(message: String) {
        updateStatus(getString(R.string.status_no_device))
        AlertDialog.Builder(this)
            .setTitle(message)
            .setPositiveButton(android.R.string.ok, null)
            .setCancelable(true)
            .show()
    }

    private fun closeAdapter() {
        try { i2cAdapter?.close() } catch (_: Exception) {}
        i2cAdapter = null
        i2cDevice = null
    }
}
