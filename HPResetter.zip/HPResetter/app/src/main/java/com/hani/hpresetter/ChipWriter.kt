package com.hani.hpresetter

import com.github.ykc3.android.usbi2c.UsbI2cDevice
import java.io.IOException

/**
 * منطق الكتابة/التحقق على EEPROM عبر I2C — نفس منطق الأردوينو الأصلي (myWire)
 * لكن باستخدام UsbI2cDevice من مكتبة usb-i2c-android فوق محول CH341.
 *
 * كل عملية I2C هنا تتكون من: كتابة [addrHigh, addrLow, ...data] كـ transaction واحدة،
 * وللقراءة: كتابة [addrHigh, addrLow] ثم قراءة منفصلة — بالظبط زي اللوجات اللي
 * سجّلناها من البرنامج الأصلي (write ثم read كعمليتين منفصلتين، مش repeated-start).
 */
class ChipWriter(
    private val device: UsbI2cDevice,
    private val onProgress: (percent: Int) -> Unit = {}
) {

    class ConnectionFailedException(message: String) : Exception(message)
    class VerifyFailedException(message: String) : Exception(message)

    /** يتأكد إن الشريحة رادّة على العنوان 0x50 قبل أي عملية. */
    @Throws(ConnectionFailedException::class)
    fun checkConnection() {
        try {
            // محاولة كتابة عنوان صفر بدون بيانات = فحص وجود الشريحة (زي endTransmission في الأردوينو)
            device.write(byteArrayOf(0x00, 0x00), 2)
        } catch (e: IOException) {
            throw ConnectionFailedException("No IC / فشل الاتصال بالشريحة")
        }
    }

    @Throws(IOException::class)
    private fun writeByteAt(address: Int, value: Byte) {
        val buf = byteArrayOf((address shr 8).toByte(), (address and 0xFF).toByte(), value)
        device.write(buf, buf.size)
    }

    @Throws(IOException::class)
    private fun readByteAt(address: Int): Byte {
        val addrBuf = byteArrayOf((address shr 8).toByte(), (address and 0xFF).toByte())
        device.write(addrBuf, addrBuf.size)
        val readBuf = ByteArray(1)
        device.read(readBuf, 1)
        return readBuf[0]
    }

    @Throws(IOException::class)
    private fun readBlock(address: Int, length: Int): ByteArray {
        val addrBuf = byteArrayOf((address shr 8).toByte(), (address and 0xFF).toByte())
        device.write(addrBuf, addrBuf.size)
        val readBuf = ByteArray(length)
        device.read(readBuf, length)
        return readBuf
    }

    /** يكتب نفس القيمة على مدى length بايت ابتداءً من address (زي write1 في الأردوينو). */
    @Throws(IOException::class)
    private fun fillRange(startAddress: Int, value: Byte, length: Int, delayMs: Long = 10) {
        for (i in 0 until length) {
            writeByteAt(startAddress + i, value)
            if (delayMs > 0) Thread.sleep(delayMs)
        }
    }

    /** يملأ كل مساحة EEPROM من 128 لحد 32768 بصفحات 64 بايت (زي fillEEPROM). */
    @Throws(IOException::class)
    private fun fillEeprom(value: Byte) {
        val eepromSize = 32768
        val pageSize = 64
        var lastPercent = -1
        var address = 128
        while (address < eepromSize) {
            val buf = ByteArray(2 + pageSize)
            buf[0] = (address shr 8).toByte()
            buf[1] = (address and 0xFF).toByte()
            for (i in 0 until pageSize) buf[2 + i] = value
            device.write(buf, buf.size)
            Thread.sleep(10)

            val percent = (((address - 128).toLong() * 100) / (eepromSize - 128)).toInt()
            if (percent != lastPercent) {
                lastPercent = percent
                onProgress(percent)
            }
            address += pageSize
        }
    }

    /** يتحقق إن كل البايتات من 96 لحد 32768 قيمتها 0xFF (زي verifyEEPROM). */
    @Throws(VerifyFailedException::class, IOException::class)
    private fun verifyEepromAllFF() {
        val blockSize = 16
        var address = 96
        var lastPercent = -1
        while (address < 32768) {
            val toRead = minOf(blockSize, 32768 - address)
            val block = readBlock(address, toRead)
            val percent = (((address - 96).toLong() * 100) / (32768 - 96)).toInt()
            if (percent != lastPercent) {
                lastPercent = percent
                onProgress(percent)
            }
            for (b in block) {
                if (b != 0xFF.toByte()) {
                    throw VerifyFailedException("فشل التحقق عند العنوان $address")
                }
            }
            address += blockSize
        }
    }

    /**
     * منطق r586 الأصلي: يقرأ السيريال (6 بايت من 0x20)، ولو كله '0' (0x30)
     * يعمل مسار مختلف عن باقي الحالات، وفي الحالتين ينتهي بـ fillEEPROM + verify.
     * (لا نعرض أي بايتات في الواجهة — فقط النتيجة النهائية نجاح/فشل)
     */
    @Throws(Exception::class)
    fun runR586() {
        checkConnection()

        val serialBuf = readBlock(0x20, 6)
        val allZero = serialBuf.all { it == 0x30.toByte() }

        if (allZero) {
            fillRange(83, 0xFF.toByte(), 45)
        } else {
            fillRange(0, 0xFF.toByte(), 31)
            fillRange(83, 0xFF.toByte(), 45)
        }
        fillEeprom(0xFF.toByte())
        verifyEepromAllFF()
    }

    /**
     * منطق burnArray الأصلي: كتابة كل بايت من data ابتداءً من startAddress،
     * مع تحقق فوري (readback) بعد كل بايت. يوقف العملية فورًا لو فشل أي بايت.
     */
    @Throws(Exception::class)
    fun burnArray(data: ByteArray, startAddress: Int, writeDelayMs: Long) {
        checkConnection()
        for (i in data.indices) {
            val addr = startAddress + i
            val value = data[i]
            writeByteAt(addr, value)
            if (writeDelayMs > 0) Thread.sleep(writeDelayMs)

            val readBack = readByteAt(addr)
            if (readBack != value) {
                throw VerifyFailedException("فشل التحقق عند العنوان $addr")
            }

            val percent = (((i + 1).toLong() * 100) / data.size).toInt()
            onProgress(percent)
        }
    }
}
